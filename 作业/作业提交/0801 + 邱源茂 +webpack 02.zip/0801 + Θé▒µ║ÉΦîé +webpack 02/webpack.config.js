const HtmlWebpackPlugin = require("html-webpack-plugin")
const { CleanWebpackPlugin } = require("clean-webpack-plugin")
const MiniCssExtractPlugin = require("mini-css-extract-plugin")

const path = require("path")

module.exports = {
    mode: "development",
    devtool: "source-map", //
    entry: {
        index: "./src/index.js",
    },

    output: {
        path: path.resolve(__dirname, "dist"),
        filename: "./js/[name].js",
    },

    module: {
        rules: [
            {
                test: /\.(png|jpg|gif)$/,
                use: {
                    loader: "url-loader",
                    options: {
                        // placeholder 占位符 [name] 源资源模块的名称
                        // [ext] 源资源模块的后缀
                        name: "[name]_[hash].[ext]",
                        //打包后的存放位置
                        outputPath: "./images",
                        // 打包后文件的 url
                        publicPath: "./images",
                        // 小于 100 字节转成 base64 格式
                        limit: 100,
                    },
                },
            },

            {
                test: /\.css$/,
                use: [
                    {
                        loader: MiniCssExtractPlugin.loader,
                    },
                    {
                        loader: "css-loader",
                        options: {
                            url: true,
                            import: true,
                            sourceMap: true,
                        },
                    },
                ],
            },
        ],
    },

    plugins: [
        new HtmlWebpackPlugin({
            title: "webpack homework",
            template: "./template/index.html",
            filename: "index.html",
        }),
        new CleanWebpackPlugin(),
        new MiniCssExtractPlugin({
            filename: "./css/[name].css",
        }),
    ],

    devServer: {
        contentBase: "./public",
        port: 8082,
        hot: true,
        hotOnly: true,
        proxy: {
            "/api": {
                target: "http://localhost:1111",
                // 路径重写,覆盖掉api
                pathRewrite: {
                    "^/api": "",
                },
            },
        },
    },
}
