import logo from "./images/logo.png"
import "./css/css.css"
import fn from "./fn.js"

let image = new Image()
image.src = logo
document.body.appendChild(image)

let btn = document.querySelector("button")

btn.onclick = function () {
    fn()
}

//如果开启 HMR
// if (module.hot) {
//   // 类似事件监听
//   module.hot.accept('./fn.js', function () {
//     console.log('fn模块变化了')
//     btn.onclick = function () {
//       fn()
//     }
//   })
// }
