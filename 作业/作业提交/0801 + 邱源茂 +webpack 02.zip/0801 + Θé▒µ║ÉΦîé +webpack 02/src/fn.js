import axios from "axios"

export default async function fn() {
    console.log("开课吧-邱源茂")

    let rs = await axios({
        url: "/api/getUser",
    })
    console.log(rs)
}
