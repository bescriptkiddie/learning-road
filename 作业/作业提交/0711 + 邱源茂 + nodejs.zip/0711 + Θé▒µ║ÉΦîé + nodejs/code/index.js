const http = require('http')
const fs = require('fs')

const server = http.createServer((req, res) => {
  //设置响应头
  res.setHeader('content-type', 'text/html; charset=utf-8')
  if (req.url === '/') {
    //默认路径
    let index = fs.readFileSync('./index.html')
    res.end(index)
  } else {
    //路径不对
    let error = fs.readFileSync('./error.html')
    res.end(error)
  }
})

server.listen(8080)
