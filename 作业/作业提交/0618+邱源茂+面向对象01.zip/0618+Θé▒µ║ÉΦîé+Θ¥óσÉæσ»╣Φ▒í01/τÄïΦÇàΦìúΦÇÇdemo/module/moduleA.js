let a
export { a }
export default  a = "hello world"