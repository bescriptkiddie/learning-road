export default class S11620{
    constructor(){
        this.name = "技能二";
        this.ico = "./sources/skills/11220.png"
    }
}