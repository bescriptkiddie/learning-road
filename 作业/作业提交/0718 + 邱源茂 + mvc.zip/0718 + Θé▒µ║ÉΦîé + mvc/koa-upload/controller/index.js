const uploadController = require('./upload.controller')
module.exports = {
  uploadController,
}
