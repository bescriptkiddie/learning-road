const uploadService = require('./upload.service')
module.exports = {
  uploadService,
}
