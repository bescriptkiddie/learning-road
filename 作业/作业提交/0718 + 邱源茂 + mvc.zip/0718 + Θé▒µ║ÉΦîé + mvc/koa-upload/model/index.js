const uploadModel = require('./upload.model')
module.exports = {
  uploadModel,
}
