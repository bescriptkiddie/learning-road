const uploadRouter = require('./upload.router')
module.exports = {
  uploadRouter,
}
