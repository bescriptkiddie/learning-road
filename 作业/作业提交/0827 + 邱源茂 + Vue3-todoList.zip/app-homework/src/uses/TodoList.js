import { ref, reactive, computed } from "vue";

function useTodoList() {

    let id = 4;

    let newTodo = ref('');

    let todos = reactive([
       {id: 1, title: '任务一', completed: false},
       {id: 2, title: '任务二', completed: true},
       {id: 3, title: '任务三', completed: false}
    ]);

    let allDone = computed( {
        get() {
            return todos.every( todo => todo.completed )
        },
        set(newVal) {
            todos.forEach(todo => todo.completed = newVal)
        }
    } )



    const addNewTodo = function() {
        todos.unshift({
            id: id++,
            title: newTodo.value,
            completed: false
        });

        newTodo.value = '';
    }
    // 获取对应的状态数据
    let filteredTodos = computed(() => {
        return filters[visibility.value](todos);
    });

    // 当 ref 作为 reactive 对象的 property 被访问或修改时，
    // 也将自动解套 value 值，其行为类似普通属性
    let visibility = ref('all');
    let state = reactive({
        visibility
    })

    // 改变分类
    const changeVisibility = function(visibility) {
         state.visibility = visibility
    }

    // 把方法写filters中
    const filters = {
        all: function (todos) {
            return todos;
        },
        active: function (todos) {
            return todos.filter(function (todo) {
                return !todo.completed;
            });
        },
        completed: function (todos) {
            return todos.filter(function (todo) {
                return todo.completed;
            });
        }
    }


    return {
        todos,
        allDone,
        filters,
        filteredTodos,
        newTodo,
        addNewTodo,
        state,
        changeVisibility
    }

}

export default useTodoList;
