const Koa = require("koa")
const Router = require("koa-router")

const app = new Koa()
const router = new Router()

//首页路由
router.get("/", ctx => {
    let html = `<h1>换个路径!!<h1>
                <a href='/getData'>换到getData</a>
                `
    ctx.body = html
})

//利用koa-router的get跳转到 /getData
router.get("/getData", ctx => {
    ctx.body = `{"name":"koa"}`
})

//加载路由中间件
app.use(router.routes())
app.listen(8080)
