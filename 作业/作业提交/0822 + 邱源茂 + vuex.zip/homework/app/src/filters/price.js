export default function(val) {
    return '¥ ' + (val/100).toFixed(2);
}