<template>
    <div>
        用户基本信息
    </div>
</template>


<style scoped>
div {
    color: red;
}
</style>