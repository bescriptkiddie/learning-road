import Vue from 'vue';
import Vuex from 'vuex';

Vue.use( Vuex );

// 构建仓库
let store = new Vuex.Store({
    // 数据存储的位置，和组件的data一样，也是响应式的
    state: {
        user: null
    },
    mutations: {
        // 初始化
        initUserInfo: state => {
            try {
                    let data = JSON.parse(localStorage.getItem('user'));
                    state.user = data;
                } catch (e) {}
            },
        // 更新
        updateUserInfo: (state, data) => {
                state.user = data;
                localStorage.setItem('user', JSON.stringify(data));
            },
        },
    actions: {

        register: ({}, data) => {
            return register(data);
        },

        login: async ({commit}, data) => {
            try {
                let rs = await login(data);
                commit('updateUserInfo', {
                    user:{
                        id: rs.data.id,
                        name: rs.data.name,
                    },
                    token: rs.headers.authorization
                });
                return rs;
            } catch (e) {
                throw e;
            }
        },
    }
});

export default store;

