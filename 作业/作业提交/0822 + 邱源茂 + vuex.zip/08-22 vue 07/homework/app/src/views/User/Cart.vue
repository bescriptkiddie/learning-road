<template>
    <div>
        用户购物车列表
    </div>
</template>


<style>

</style>