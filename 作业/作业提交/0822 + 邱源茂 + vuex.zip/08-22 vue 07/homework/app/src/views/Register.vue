<template>
    <div>
        注册
    </div>
</template>

<script>
export default {
    name: 'Register'
}
</script>