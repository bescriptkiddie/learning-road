<template>
    <header id="header">
        <a href="/" id="logo"></a>

        <nav id="nav">
            <a href="">手机</a>
            <a href="">笔记本</a>
            <a href="">家居</a>
        </nav>

        <div id="user">
<!--            {{$store.state.user}}-->
<!--            <button @click="changeUser">{{$store.state.user}}</button>-->
            <div id="logined" v-if="user">
                <router-link :to="{name:'User'}">{{user.name}}</router-link>
            </div>
            <div id="beforeLogin" v-else>
                <router-link :to="{name: 'Login'}">登录</router-link>
                <a href="">注册</a>
            </div>
        </div>
    </header>
</template>

<script>
    import {mapState} from 'vuex';
    // import store from '@/store'
    export default {
        name: 'KHeader',

        computed: {
          ...mapState({
            user: state => state.user
          })
        },
        methods: {
            async changeUser() {
              await this.$store.dispatch('initUserInfo');
            }
        }
}
</script>
