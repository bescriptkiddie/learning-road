export default class Skin3{
    constructor(){
        this.name = "皮肤三";
        this.ico = "./sources/heros/luban3.png";
        this.img = "./sources/skins/301122.png";
    }
}