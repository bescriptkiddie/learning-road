const Koa = require("koa")
const serve = require("koa-static")
const Router = require("koa-router")
const koaBody = require("koa-body")
const { initDB } = require("./db")
const { uploadRouter, getPhotosRouter } = require("./router")

initDB()
const app = new Koa()
app.use(serve(__dirname + "/static"))

app.use(
    koaBody({
        multipart: true,
    })
)
app.use(uploadRouter.routes())
app.use(getPhotosRouter.routes())

app.listen(8080)
