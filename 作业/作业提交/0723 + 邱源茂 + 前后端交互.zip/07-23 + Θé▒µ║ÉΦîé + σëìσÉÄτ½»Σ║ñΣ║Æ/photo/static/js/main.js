// 前端逻辑
import PreviewImg from './PreviewImg.js'
import { upload } from './upload.js'

const imgFile = document.querySelector('.imgFile')
const imgFileAdd = document.querySelector('.imgFile-add')
const showContainer = document.querySelector('.showContainer')
const loadContainer = document.querySelector('.loadContainer')
const uploadBtn = document.querySelector('.uploadBtn')
const paratElement = document.querySelector('.photoContainer')

;(async () => {
  renderShowImg
})()

async function renderShowImg() {
  paratElement.innerHtml = ``
  const res = await axios.get('/getPhotos')
  const data = res.data
  data.forEach((photoInfo) => {
    new ShowImg(photoInfo)
  })
}

let uploadImgList = []
uploadBtn.addEventListener('click', async () => {
  // 上传图片到服务器
  for (const previewImg of uploadImgList) {
    await upload(previewImg)
  }
  // 上传完成了
  uploadCompleted()
  await renderShowImg()
})

function uploadCompleted() {
  paratElement.innerHTML = ``
  reset()
}

function reset() {
  hideLoadContainer()
  uploadImgList = []
}

imgFileAdd.addEventListener('change', (e) => {
  renderPreviewImg(e.target.files)
})

imgFile.addEventListener('change', (e) => {
  renderPreviewImg(e.target.files)
})

function renderPreviewImg(files) {
  const fileList = Array.from(files)

  fileList.forEach((file) => {
    const previewImg = new PreviewImg(file)
    uploadImgList.push(previewImg)
  })

  showLoadContainer()
}

function showLoadContainer() {
  showContainer.style.display = 'none'
  loadContainer.style.display = 'block'
}

function hideLoadContainer() {
  showContainer.style.display = 'block'
  loadContainer.style.display = 'none'
}

class ShowImg {
  constructor(data) {
    this.data = data
    this.createElement()
  }
  createElement() {
    const div = document.createElement('div')
    div.classList.add('photoItem')
    div.innerHTML = `
            <img src="${this.data.imgUrl}">
            <span>${this.data.name}</span>
        `
    paratElement.appendChild(div)
    console.log(div)
    return div
  }
}
