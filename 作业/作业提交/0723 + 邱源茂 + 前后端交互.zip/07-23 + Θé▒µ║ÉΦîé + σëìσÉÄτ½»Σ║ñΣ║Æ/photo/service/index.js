const uploadService = require('./upload.service')
const getPhotosService = require('./getPhotos.service')
module.exports = {
  uploadService,
  getPhotosService,
}
