const { getPhotosModel } = require('../model')
module.exports = {
  async getPhotos() {
    const result = await getPhotosModel.findAll()
    return result
  },
}
