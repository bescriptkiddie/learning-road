const { uploadService } = require('../service')

module.exports = {
  async addData(ctx) {
    const { img } = ctx.request.files
    const result = await uploadService.addData(img)
    // console.log(result)
    ctx.body = result
  },
}
