const uploadController = require("./upload.controller")
const getPhotosController = require("./getPhotos.controller")
module.exports = {
    uploadController,
    getPhotosController,
}
