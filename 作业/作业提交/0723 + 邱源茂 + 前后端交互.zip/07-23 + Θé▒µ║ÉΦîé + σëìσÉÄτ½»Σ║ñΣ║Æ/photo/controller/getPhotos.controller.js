const { getPhotosService } = require('../service')

module.exports = {
  async getPhotos(ctx) {
    const result = await getPhotosService.getPhotos()
    ctx.body = result
  },
}
