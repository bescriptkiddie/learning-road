const { getDB } = require("../db")
module.exports = {
    async create({ name, newTime, imgUrl }) {
        const sql =
            "INSERT INTO photos (id,name,imgUrl,newTime) VALUES (0,?,?,?)"
        const [result] = await getDB().execute(sql, [name, imgUrl, newTime])
        return result
    },
}
