const uploadModel = require("./upload.model")
const getPhotosModel = require("./getPhotos.model")
module.exports = {
    uploadModel,
    getPhotosModel,
}
