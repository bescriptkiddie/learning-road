const { getDB } = require('../db')
module.exports = {
  async findAll() {
    const sql = `SELECT * FROM photos `
    const [rows] = await getDB().execute(sql)
    return rows
  },
}
