const uploadRouter = require("./upload.router")
const getPhotosRouter = require("./getPhotos.router")
module.exports = {
    uploadRouter,
    getPhotosRouter,
}
