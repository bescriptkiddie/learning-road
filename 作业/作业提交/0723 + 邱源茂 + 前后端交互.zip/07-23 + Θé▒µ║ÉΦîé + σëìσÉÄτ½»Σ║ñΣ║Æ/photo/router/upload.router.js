const Router = require('koa-router')
const { uploadController } = require('../controller')
const router = new Router()

router.post('/upload/addData', uploadController.addData)

module.exports = router
