const Router = require('koa-router')
const { getPhotosController } = require('../controller')
const router = new Router()

router.get('/getPhotos', getPhotosController.getPhotos)

module.exports = router
