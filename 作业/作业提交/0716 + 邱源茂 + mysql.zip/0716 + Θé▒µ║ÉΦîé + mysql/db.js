// 1 连接
const mysql = require("mysql2")

const connection = mysql.createConnection({
    // host:localhost,
    user: "root",
    password: "wywy1203",
    database: "kkb",
})

//添加一条数据
const name = "xiaoming"
const age = 19
// 防止sql注入,用'?'来占位
const sql = `INSERT INTO users (name,age) VALUES (?,?)`
connection.query(sql, [name, age], (err, results) => {
    if (err) {
        throw err
    }
    console.log(results) // results contains rows returned by server
    //   console.log(fields); // fields contains extra meta data about results, if available
})
