// 1 连接
const mysql = require("mysql2/promise")
;(async () => {
    const connection = await mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "wywy1203",
        database: "kkb",
    })
    const name = "xiaoming"
    const age = 19
    const sql = `INSERT INTO users (name,age) VALUES (?,?)`
    const results = await connection.execute(sql, [name, age])
    console.log(results)
})()
