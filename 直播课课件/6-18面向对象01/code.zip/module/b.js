console.log("b...");
export default {name:"b模块"};